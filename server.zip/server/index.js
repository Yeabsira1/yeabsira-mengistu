 const express= require("express");
const app= express();
const mysql= require("mysql2");
const cors=require("cors");
const bodyParser= require("body-parser");
const useroutes=require('./routes/routes');

app.use(useroutes);

app.use(cors(
    {    
        origin: ["http://localhost:3000"],
        methods:["POST","GET","DELETE","PUT"],
        credentials:true
    }
));
app.use(express.json()); 
app.use(bodyParser.urlencoded({extended:false}));

const db= mysql.createConnection({
    host:"localhost",
    user: "root",
    password: "root123456!",
    database: "excel"
    

})



app.listen(5000, ()=>{
    console.log("server is running");
})