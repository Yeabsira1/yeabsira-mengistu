
const post=(req,res)=>{
    const {item_no,description,unit,qty,rate,amount}=req.body;
    
    const sqlPost=`INSERT INTO exceldata (item_no,description,unit,qty,rate,amount) VALUES (?,?,?,?,?,?)`;
 const u= db.query(sqlPost, [item_no,description,unit,qty,rate,amount],(err,result)=>{
    res.send(result);
    
  });
}
const get=(req,res)=>{
    const sqlGet="SELECT * FROM exceldata";
db.query(sqlGet,(error,result)=>{
    res.send(result);
});}

const del= (req,res)=>{
    const {item_no}=req.params; 
    const sqlGet="DELETE FROM exceldata  WHERE item_no=  ? ";
    const u= db.query(sqlGet,item_no,(error,result)=>{
    res.send(result); 
  
});}
const deleteall=(req,res)=>{
    const sqlGet="DELETE FROM exceldata WHERE item_no>0";
    const u= db.query(sqlGet,(error,result)=>{
    res.send(result); 
  
});}
module.exports={
post,get,del,deleteall
}