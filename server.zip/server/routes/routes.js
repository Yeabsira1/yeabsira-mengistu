const express= require("express");
const router=express.Router();
const controller=require('../controller/controller.js');

router.post("/api/post/exceldata", controller.post);

router.get("/api/get/exceldata", controller.get);

router.delete("/del/:item_no", controller.del);
router.delete("/del/alldata", controller.deleteall );
module.exports=router;